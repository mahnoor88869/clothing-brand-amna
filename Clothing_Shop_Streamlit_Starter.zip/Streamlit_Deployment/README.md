# Clothing Shop Sales and Customer Feedback Assistant

This is the Streamlit deployment starter for **AI for Everyone – Project 02**. It uses the supplied `Project_02` classroom dataset and the models trained by the Colab workflow.

## Important project limitations
- Sales records are generated classroom data, not real shop transactions. Demand outputs are estimates, not confirmed forecasts.
- KMeans groups are product-planning scenarios, not customer segments.
- The CNN recognises only `top`, `trouser`, and `bag` from small grayscale catalogue-style images. It may not generalise to ordinary phone photos.
- VADER is an English lexicon baseline; sarcasm, mixed opinions, Urdu and Roman Urdu are limitations.
- The app loads saved models only; model training happens in Colab.
- Groq is optional. The offline weekly summary works without an API key.

## Files created by Colab
After running `Colab_Workflow/Clothing_Shop_Full_Workflow.ipynb`, download the generated `Clothing-Shop-Deployment.zip`. That ZIP contains the trained models and all runtime files required here. It should include:

```text
app.py
requirements.txt
README.md
models/
  supervised.joblib
  clusters.joblib
  images.keras
  group_descriptions.json
data/
  main.csv
  feedback.csv
  example_inputs.csv
  meta.json
  topic_keywords.json
sample_images/
nltk_data/
source_notices/
```

The large training-only `data/images.npz` and `image_manifest.csv` are not required by the deployed app and should not be committed to the public repository. Keep the source notices.

## Run locally
Use Python 3.11, then run:

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Groq API key (optional)
1. Create a key in the [Groq Console](https://console.groq.com/). Never paste it into chat, source code, GitHub, or screenshots.
2. In Streamlit Community Cloud, open your app's **Settings → Secrets** and add:

```toml
GROQ_API_KEY = "paste-your-new-key-here"
GROQ_MODEL = "openai/gpt-oss-20b"
```

3. Keep the key private. If a key was previously shared or committed, revoke it and create a new one.
4. Check model availability and your account quota in Groq Console. Do not enable paid billing unless you deliberately choose to.

## Deploy on Streamlit Community Cloud
1. Run all cells in the Colab notebook from top to bottom.
2. Download and extract `Clothing-Shop-Deployment.zip` generated at the end.
3. Upload the extracted deployment folder contents to a GitHub repository.
4. On [Streamlit Community Cloud](https://share.streamlit.io/), create an app from that repository and select `app.py` as the main file.
5. In Advanced settings choose **Python 3.11**.
6. Add the optional Groq values under Settings → Secrets.
7. Deploy. If you do not add a Groq key, all non-LLM tabs and the offline weekly review should still work.

## Dataset source
The data and source notices are copied from the supplied `Project_02.zip`. The training notebook expects that ZIP to be uploaded to the Colab session.
